import React from 'react';
import { 
  Code, 
  Heart, 
  Github, 
  Linkedin, 
  Instagram, 
  MessageCircle,
  Mail,
  ExternalLink,
  ArrowUp
} from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const quickLinks = [
    { label: 'Home', id: 'hero' },
    { label: 'Services', id: 'services' },
    { label: 'Portfolio', id: 'portfolio' },
    { label: 'About', id: 'about' },
    { label: 'Contact', id: 'contact' }
  ];

  const services = [
    'WordPress Development',
    'Shopify Solutions',
    'Webflow Development',
    'Custom Web Development',
    'SEO Optimization',
    'Website Maintenance'
  ];

  const socialLinks = [
    {
      icon: Github,
      name: 'GitHub',
      url: 'https://github.com/webd2276'
    },
    {
      icon: Linkedin,
      name: 'LinkedIn',
      url: 'https://linkedin.com/in/hamza-qadeer-830671348'
    },
    {
      icon: Instagram,
      name: 'Instagram',
      url: 'https://instagram.com/webd2276'
    },
    {
      icon: ExternalLink,
      name: 'Fiverr',
      url: 'https://fiverr.com/webdeveloper534'
    }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand & Description */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <Code className="h-8 w-8 text-blue-400" />
              <span className="text-xl font-bold">Hamza Qadeer</span>
            </div>
            <p className="text-gray-400 mb-6">
              Professional web developer specializing in WordPress, Shopify, and custom web solutions. 
              Creating digital experiences that drive business growth.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-2 text-sm">
              <div className="flex items-center">
                <MessageCircle className="h-4 w-4 text-blue-400 mr-2" />
                <span>+92 302 3487168</span>
              </div>
              <div className="flex items-center">
                <Mail className="h-4 w-4 text-blue-400 mr-2" />
                <span>webd2276@gmail.com</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(link.id)}
                    className="text-gray-400 hover:text-white transition-colors duration-200"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2">
              {services.map((service, index) => (
                <li key={index} className="text-gray-400 text-sm">
                  {service}
                </li>
              ))}
            </ul>
          </div>

          {/* Social Links & CTA */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Connect With Me</h3>
            <div className="flex space-x-3 mb-6">
              {socialLinks.map((social, index) => {
                const Icon = social.icon;
                return (
                  <button
                    key={index}
                    onClick={() => window.open(social.url, '_blank')}
                    className="w-10 h-10 bg-gray-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors duration-200"
                    title={social.name}
                  >
                    <Icon className="h-5 w-5" />
                  </button>
                );
              })}
            </div>
            
            <div className="bg-gray-800 rounded-lg p-4">
              <h4 className="font-semibold mb-2">Ready to Start?</h4>
              <p className="text-gray-400 text-sm mb-3">
                Let's discuss your project and bring your ideas to life.
              </p>
              <button
                onClick={() => window.open('https://wa.me/923023487168', '_blank')}
                className="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-sm font-medium transition-colors duration-200"
              >
                Start Project
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center text-gray-400 text-sm mb-4 md:mb-0">
              <span>© {currentYear} Hamza Qadeer. Made with</span>
              <Heart className="h-4 w-4 text-red-500 mx-1" />
              <span>in Pakistan</span>
            </div>
            
            <div className="flex items-center space-x-6 text-sm">
              <button className="text-gray-400 hover:text-white transition-colors duration-200">
                Privacy Policy
              </button>
              <button className="text-gray-400 hover:text-white transition-colors duration-200">
                Terms of Service
              </button>
              <button
                onClick={scrollToTop}
                className="flex items-center text-gray-400 hover:text-white transition-colors duration-200"
              >
                <ArrowUp className="h-4 w-4 mr-1" />
                Back to Top
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;