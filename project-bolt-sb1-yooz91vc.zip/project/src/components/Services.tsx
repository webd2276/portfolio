import React from 'react';
import { 
  Globe, 
  ShoppingCart, 
  Palette, 
  Code, 
  Smartphone, 
  Search,
  ArrowRight,
  CheckCircle
} from 'lucide-react';

const Services: React.FC = () => {
  const services = [
    {
      icon: Globe,
      title: 'WordPress Development',
      description: 'Custom WordPress themes, plugins, and full-stack solutions using Classic Editor, Gutenberg, and popular page builders.',
      features: ['Custom Theme Development', 'Plugin Development', 'WooCommerce Integration', 'Performance Optimization'],
      color: 'blue'
    },
    {
      icon: ShoppingCart,
      title: 'Shopify Solutions',
      description: 'Complete Shopify store development, custom themes, Liquid templating, and app integrations for e-commerce success.',
      features: ['Custom Shopify Themes', 'Liquid Development', 'App Integration', 'Store Optimization'],
      color: 'green'
    },
    {
      icon: Palette,
      title: 'Google Sites & Webflow',
      description: 'Professional website creation using Google Sites and advanced Webflow development for modern, responsive designs.',
      features: ['Google Sites Customization', 'Webflow Development', 'Responsive Design', 'CMS Integration'],
      color: 'purple'
    },
    {
      icon: Code,
      title: 'Custom Web Development',
      description: 'Full-stack web development using modern technologies including PHP, JavaScript, and responsive frameworks.',
      features: ['Custom PHP Applications', 'JavaScript Development', 'Database Design', 'API Integration'],
      color: 'orange'
    },
    {
      icon: Smartphone,
      title: 'Responsive Design',
      description: 'Mobile-first, responsive web design ensuring perfect user experience across all devices and screen sizes.',
      features: ['Mobile-First Design', 'Cross-Browser Compatibility', 'Performance Optimization', 'User Experience'],
      color: 'pink'
    },
    {
      icon: Search,
      title: 'SEO & Performance',
      description: 'Search engine optimization and performance enhancement to improve visibility and user experience.',
      features: ['Technical SEO', 'Page Speed Optimization', 'Schema Markup', 'Analytics Setup'],
      color: 'indigo'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/20',
      green: 'text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-900/20',
      purple: 'text-purple-600 dark:text-purple-400 bg-purple-100 dark:bg-purple-900/20',
      orange: 'text-orange-600 dark:text-orange-400 bg-orange-100 dark:bg-orange-900/20',
      pink: 'text-pink-600 dark:text-pink-400 bg-pink-100 dark:bg-pink-900/20',
      indigo: 'text-indigo-600 dark:text-indigo-400 bg-indigo-100 dark:bg-indigo-900/20'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <section id="services" className="py-20 bg-gray-50 dark:bg-gray-800/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Professional Services
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            I offer comprehensive web development services to help businesses establish a strong online presence 
            and achieve their digital goals.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            const colorClasses = getColorClasses(service.color);
            
            return (
              <div
                key={index}
                className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group"
              >
                {/* Icon */}
                <div className={`w-12 h-12 rounded-lg ${colorClasses} flex items-center justify-center mb-4`}>
                  <Icon className="h-6 w-6" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                  {service.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  {service.description}
                </p>

                {/* Features */}
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <button className="flex items-center text-blue-600 dark:text-blue-400 font-medium group-hover:text-blue-700 dark:group-hover:text-blue-300 transition-colors duration-200">
                  Learn More
                  <ArrowRight className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform duration-200" />
                </button>
              </div>
            );
          })}
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">Ready to Start Your Project?</h3>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              Let's discuss your requirements and create something amazing together. 
              I'm here to help bring your vision to life.
            </p>
            <button
              onClick={() => window.open('https://wa.me/923023487168', '_blank')}
              className="px-8 py-3 bg-white text-blue-600 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-200"
            >
              Get Free Consultation
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;