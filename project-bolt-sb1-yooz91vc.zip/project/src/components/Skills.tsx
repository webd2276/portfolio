import React from 'react';
import { Code2, Database, Palette, Globe, Wrench, TrendingUp } from 'lucide-react';

const Skills: React.FC = () => {
  const skillCategories = [
    {
      icon: Code2,
      title: 'Frontend Development',
      skills: [
        { name: 'HTML5', level: 95 },
        { name: 'CSS3', level: 90 },
        { name: 'JavaScript', level: 85 },
        { name: 'jQuery', level: 80 },
        { name: 'Bootstrap', level: 90 },
        { name: 'Tailwind CSS', level: 85 }
      ],
      color: 'blue'
    },
    {
      icon: Database,
      title: 'Backend Development',
      skills: [
        { name: 'PHP', level: 90 },
        { name: 'MySQL', level: 85 },
        { name: 'WordPress', level: 95 },
        { name: 'Node.js', level: 75 },
        { name: 'REST APIs', level: 80 },
        { name: 'Database Design', level: 85 }
      ],
      color: 'green'
    },
    {
      icon: Palette,
      title: 'Design & CMS',
      skills: [
        { name: 'Responsive Design', level: 95 },
        { name: 'UI/UX Design', level: 80 },
        { name: 'Shopify', level: 90 },
        { name: 'Webflow', level: 85 },
        { name: 'Google Sites', level: 90 },
        { name: 'Figma', level: 75 }
      ],
      color: 'purple'
    },
    {
      icon: Wrench,
      title: 'Tools & Technologies',
      skills: [
        { name: 'Git/GitHub', level: 85 },
        { name: 'cPanel', level: 90 },
        { name: 'XAMPP', level: 85 },
        { name: 'VS Code', level: 95 },
        { name: 'Chrome DevTools', level: 90 },
        { name: 'Postman', level: 80 }
      ],
      color: 'orange'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/20',
      green: 'text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-900/20',
      purple: 'text-purple-600 dark:text-purple-400 bg-purple-100 dark:bg-purple-900/20',
      orange: 'text-orange-600 dark:text-orange-400 bg-orange-100 dark:bg-orange-900/20'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  const getProgressColor = (color: string) => {
    const colors = {
      blue: 'bg-blue-600',
      green: 'bg-green-600',
      purple: 'bg-purple-600',
      orange: 'bg-orange-600'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <section id="skills" className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Technical Skills
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            A comprehensive overview of my technical expertise and proficiency levels 
            across various web development technologies and tools.
          </p>
        </div>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {skillCategories.map((category, categoryIndex) => {
            const Icon = category.icon;
            const colorClasses = getColorClasses(category.color);
            const progressColor = getProgressColor(category.color);

            return (
              <div
                key={categoryIndex}
                className="bg-gray-50 dark:bg-gray-800 rounded-xl p-6"
              >
                {/* Category Header */}
                <div className="flex items-center mb-6">
                  <div className={`w-10 h-10 rounded-lg ${colorClasses} flex items-center justify-center mr-3`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                    {category.title}
                  </h3>
                </div>

                {/* Skills List */}
                <div className="space-y-4">
                  {category.skills.map((skill, skillIndex) => (
                    <div key={skillIndex}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          {skill.name}
                        </span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {skill.level}%
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${progressColor} transition-all duration-1000 ease-out`}
                          style={{ width: `${skill.level}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Certifications & Achievements */}
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-800 dark:to-gray-800 rounded-2xl p-8">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Certifications & Achievements
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Continuous learning and professional development in web technologies
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="h-8 w-8 text-white" />
              </div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                Web Development Certified
              </h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Certified in modern web development practices and technologies
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="h-8 w-8 text-white" />
              </div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                WordPress Expert
              </h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Advanced WordPress development and customization expertise
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Code2 className="h-8 w-8 text-white" />
              </div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                Full-Stack Developer
              </h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Proficient in both frontend and backend development
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;