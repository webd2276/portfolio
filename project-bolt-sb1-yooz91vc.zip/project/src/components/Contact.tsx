import React, { useState } from 'react';
import { 
  Mail, 
  Phone, 
  MessageCircle, 
  MapPin, 
  Clock, 
  Send,
  Github,
  Linkedin,
  Instagram,
  ExternalLink
} from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    projectType: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, this would send the form data to a server
    const whatsappMessage = `Hi Hamza! I'm interested in your web development services.

Name: ${formData.name}
Email: ${formData.email}
Project Type: ${formData.projectType}
Subject: ${formData.subject}

Message: ${formData.message}`;

    const encodedMessage = encodeURIComponent(whatsappMessage);
    window.open(`https://wa.me/923023487168?text=${encodedMessage}`, '_blank');
  };

  const contactMethods = [
    {
      icon: MessageCircle,
      title: 'WhatsApp',
      value: '+92 302 3487168',
      action: () => window.open('https://wa.me/923023487168', '_blank'),
      color: 'green'
    },
    {
      icon: Mail,
      title: 'Email',
      value: 'webd2276@gmail.com',
      action: () => window.open('mailto:webd2276@gmail.com', '_blank'),
      color: 'blue'
    },
    {
      icon: Phone,
      title: 'Phone',
      value: '+92 302 3487168',
      action: () => window.open('tel:+923023487168', '_blank'),
      color: 'purple'
    }
  ];

  const socialLinks = [
    {
      icon: Github,
      name: 'GitHub',
      url: 'https://github.com/webd2276',
      color: 'gray'
    },
    {
      icon: Linkedin,
      name: 'LinkedIn',
      url: 'https://linkedin.com/in/hamza-qadeer-830671348',
      color: 'blue'
    },
    {
      icon: Instagram,
      name: 'Instagram',
      url: 'https://instagram.com/webd2276',
      color: 'pink'
    },
    {
      icon: ExternalLink,
      name: 'Fiverr',
      url: 'https://fiverr.com/webdeveloper534',
      color: 'green'
    },
    {
      icon: ExternalLink,
      name: 'Upwork',
      url: 'https://upwork.com/~01ed30bcd8b418a670',
      color: 'blue'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      green: 'text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-900/20 hover:bg-green-200 dark:hover:bg-green-900/30',
      blue: 'text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/20 hover:bg-blue-200 dark:hover:bg-blue-900/30',
      purple: 'text-purple-600 dark:text-purple-400 bg-purple-100 dark:bg-purple-900/20 hover:bg-purple-200 dark:hover:bg-purple-900/30',
      gray: 'text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700',
      pink: 'text-pink-600 dark:text-pink-400 bg-pink-100 dark:bg-pink-900/20 hover:bg-pink-200 dark:hover:bg-pink-900/30'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <section id="contact" className="py-20 bg-gray-50 dark:bg-gray-800/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Get In Touch
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Ready to start your next project? I'm here to help bring your ideas to life. 
            Let's discuss how we can work together to create something amazing.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div>
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              Let's Start a Conversation
            </h3>
            
            <p className="text-gray-600 dark:text-gray-400 mb-8">
              I'm always excited to discuss new projects and opportunities. Whether you need 
              a complete website overhaul, custom development, or just have questions about 
              web development, I'm here to help.
            </p>

            {/* Contact Methods */}
            <div className="space-y-4 mb-8">
              {contactMethods.map((method, index) => {
                const Icon = method.icon;
                const colorClasses = getColorClasses(method.color);
                
                return (
                  <button
                    key={index}
                    onClick={method.action}
                    className={`w-full flex items-center p-4 rounded-lg ${colorClasses} transition-all duration-200 text-left`}
                  >
                    <Icon className="h-6 w-6 mr-4 flex-shrink-0" />
                    <div>
                      <div className="font-semibold">{method.title}</div>
                      <div className="text-sm opacity-80">{method.value}</div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Business Hours */}
            <div className="bg-white dark:bg-gray-900 rounded-lg p-6 mb-8">
              <div className="flex items-center mb-4">
                <Clock className="h-6 w-6 text-blue-600 dark:text-blue-400 mr-3" />
                <h4 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Business Hours
                </h4>
              </div>
              <div className="space-y-2 text-gray-600 dark:text-gray-400">
                <div className="flex justify-between">
                  <span>Monday - Friday</span>
                  <span>9:00 AM - 6:00 PM (PKT)</span>
                </div>
                <div className="flex justify-between">
                  <span>Saturday</span>
                  <span>10:00 AM - 4:00 PM (PKT)</span>
                </div>
                <div className="flex justify-between">
                  <span>Sunday</span>
                  <span>Emergency Support Only</span>
                </div>
              </div>
              <div className="mt-4 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div className="flex items-center text-green-600 dark:text-green-400">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                  <span className="text-sm font-medium">Usually responds within 2 hours</span>
                </div>
              </div>
            </div>

            {/* Social Links */}
            <div>
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Connect With Me
              </h4>
              <div className="flex flex-wrap gap-3">
                {socialLinks.map((social, index) => {
                  const Icon = social.icon;
                  const colorClasses = getColorClasses(social.color);
                  
                  return (
                    <button
                      key={index}
                      onClick={() => window.open(social.url, '_blank')}
                      className={`flex items-center px-4 py-2 rounded-lg ${colorClasses} transition-all duration-200`}
                      title={social.name}
                    >
                      <Icon className="h-5 w-5 mr-2" />
                      <span className="text-sm font-medium">{social.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white dark:bg-gray-900 rounded-xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              Send Me a Message
            </h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    placeholder="Your full name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    placeholder="your.email@example.com"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="projectType" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Project Type
                </label>
                <select
                  id="projectType"
                  name="projectType"
                  value={formData.projectType}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                >
                  <option value="">Select project type</option>
                  <option value="wordpress">WordPress Development</option>
                  <option value="shopify">Shopify Store</option>
                  <option value="webflow">Webflow Website</option>
                  <option value="custom">Custom Development</option>
                  <option value="maintenance">Website Maintenance</option>
                  <option value="consultation">Consultation</option>
                </select>
              </div>

              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Subject *
                </label>
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  placeholder="Brief description of your project"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Message *
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  required
                  rows={6}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white resize-none"
                  placeholder="Tell me more about your project requirements, timeline, and budget..."
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
              >
                <Send className="h-5 w-5" />
                <span>Send Message via WhatsApp</span>
              </button>
            </form>

            <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <p className="text-sm text-blue-600 dark:text-blue-400">
                <strong>Note:</strong> This form will open WhatsApp with your message pre-filled. 
                You can also contact me directly through any of the methods above.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;