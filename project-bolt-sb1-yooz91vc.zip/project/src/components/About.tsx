import React from 'react';
import { Download, Award, Clock, Users, Star, MapPin } from 'lucide-react';

const About: React.FC = () => {
  const achievements = [
    { icon: Users, label: 'Happy Clients', value: '50+' },
    { icon: Award, label: 'Projects Completed', value: '100+' },
    { icon: Clock, label: 'Years Experience', value: '3+' },
    { icon: Star, label: 'Client Rating', value: '4.9/5' }
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Business Owner',
      content: 'Hamza delivered an exceptional WordPress website for my business. His attention to detail and professional approach exceeded my expectations.',
      rating: 5
    },
    {
      name: 'Mike Chen',
      role: 'E-commerce Manager',
      content: 'Outstanding Shopify development work! The custom theme and functionality perfectly matched our requirements. Highly recommended.',
      rating: 5
    },
    {
      name: 'Emily Davis',
      role: 'Marketing Director',
      content: 'Professional, reliable, and skilled developer. Hamza transformed our outdated website into a modern, responsive platform.',
      rating: 5
    }
  ];

  const downloadResume = () => {
    // In a real application, this would download the actual resume file
    const link = document.createElement('a');
    link.href = '/resume-hamza-qadeer.pdf';
    link.download = 'Hamza-Qadeer-Resume.pdf';
    link.click();
  };

  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            About Me
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Passionate web developer with a commitment to creating exceptional digital experiences 
            and helping businesses succeed online.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* About Content */}
          <div>
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              Professional Web Developer & Digital Solutions Expert
            </h3>
            
            <div className="space-y-4 text-gray-600 dark:text-gray-400">
              <p>
                With over 3 years of experience in web development, I specialize in creating 
                custom websites and digital solutions that drive business growth. My expertise 
                spans across multiple platforms including WordPress, Shopify, Webflow, and 
                custom web development.
              </p>
              
              <p>
                I believe in the power of clean code, responsive design, and user-centered 
                development. Every project I undertake is approached with meticulous attention 
                to detail, ensuring optimal performance, security, and user experience.
              </p>
              
              <p>
                My goal is to help businesses establish a strong online presence through 
                innovative web solutions that not only look great but also deliver measurable 
                results. I'm committed to staying updated with the latest web technologies 
                and best practices.
              </p>
            </div>

            {/* Location & Availability */}
            <div className="mt-6 flex items-center space-x-6">
              <div className="flex items-center text-gray-600 dark:text-gray-400">
                <MapPin className="h-5 w-5 mr-2 text-blue-600 dark:text-blue-400" />
                <span>Pakistan (Remote Worldwide)</span>
              </div>
              <div className="flex items-center text-green-600 dark:text-green-400">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                <span>Available for Projects</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="mt-8 flex flex-col sm:flex-row gap-4">
              <button
                onClick={downloadResume}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
              >
                <Download className="h-5 w-5" />
                <span>Download Resume</span>
              </button>
              <button
                onClick={() => window.open('https://wa.me/923023487168', '_blank')}
                className="px-6 py-3 border-2 border-blue-600 text-blue-600 dark:text-blue-400 hover:bg-blue-600 hover:text-white dark:hover:text-white rounded-lg font-semibold transition-colors duration-200"
              >
                Let's Work Together
              </button>
            </div>
          </div>

          {/* Profile Image & Stats */}
          <div className="text-center">
            <div className="relative inline-block mb-8">
              <img
                src="/hamza.png"
                alt="Hamza Qadeer - Web Developer"
                className="w-64 h-64 rounded-full object-cover border-8 border-white dark:border-gray-800 shadow-2xl"
                loading="lazy"
              />
              <div className="absolute -bottom-4 -right-4 bg-green-500 text-white px-4 py-2 rounded-full text-sm font-semibold">
                Available
              </div>
            </div>

            {/* Achievement Stats */}
            <div className="grid grid-cols-2 gap-4">
              {achievements.map((achievement, index) => {
                const Icon = achievement.icon;
                return (
                  <div
                    key={index}
                    className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 text-center"
                  >
                    <Icon className="h-8 w-8 text-blue-600 dark:text-blue-400 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">
                      {achievement.value}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      {achievement.label}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Testimonials */}
        <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white text-center mb-8">
            What Clients Say
          </h3>
          
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-white dark:bg-gray-900 rounded-lg p-6 shadow-lg"
              >
                {/* Rating */}
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                
                {/* Content */}
                <p className="text-gray-600 dark:text-gray-400 mb-4 italic">
                  "{testimonial.content}"
                </p>
                
                {/* Author */}
                <div>
                  <div className="font-semibold text-gray-900 dark:text-white">
                    {testimonial.name}
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    {testimonial.role}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;